class Particle: 
    def __init__(self, stiffness, expansion):
        self.stiffness = stiffness 
        self.expansion = expansion
    
    # def mutate(self, mutate_stiffness, mutate_size):
    #     if mutate_stiffness: pass
    #     if mutate_size: pass 
    #     #mutate stiffness and inflation degree 
